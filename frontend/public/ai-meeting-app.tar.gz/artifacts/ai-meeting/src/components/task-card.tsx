import { Task } from "@/types";
import { Github, Lightbulb, MapPin, Users, Link2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TaskCardProps {
  task: Task;
}

const PRIORITY_STYLES: Record<string, { badge: string; icon: string }> = {
  HIGH: { badge: "bg-red-500 text-white", icon: "🔴" },
  MEDIUM: { badge: "bg-amber-400 text-white", icon: "🟡" },
  LOW: { badge: "bg-green-500 text-white", icon: "🟢" }
};

const TEAM_ICONS: Record<string, string> = {
  Backend: "🔧",
  "UI/UX": "🎨",
  API: "⚡",
  Frontend: "💻",
  Infrastructure: "🏗️"
};

export function TaskCard({ task }: TaskCardProps) {
  const { toast } = useToast();
  const priority = PRIORITY_STYLES[task.priority] || PRIORITY_STYLES.LOW;

  const handleCreateIssue = (e: React.MouseEvent) => {
    e.stopPropagation();
    toast({
      title: "✓ GitHub Issue Created",
      description: `"${task.title}" has been added to your repository.`,
    });
  };

  return (
    <div className="group bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 overflow-hidden">
      <div className="px-4 pt-3.5 pb-3">
        <div className="flex items-start justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-base shrink-0">{TEAM_ICONS[task.team] || "📋"}</span>
            <h4 className="font-semibold text-slate-900 text-sm leading-snug truncate">
              {task.title}
            </h4>
          </div>
          <span className={`shrink-0 text-[10px] font-bold px-2.5 py-1 rounded-full tracking-wide ${priority.badge}`}>
            {task.priority}
          </span>
        </div>

        <div className="space-y-1.5 text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 shrink-0 text-slate-400" />
            <span>Assigned To: <span className="text-slate-700 font-medium">{task.assignee}</span></span>
          </div>

          {task.dependentOn && (
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 shrink-0 text-slate-400" />
              <span>Priority </span>
              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${priority.badge}`}>
                {task.priority}
              </span>
              <span>Dependent on</span>
              <span className="bg-indigo-100 text-indigo-700 font-medium px-1.5 py-0.5 rounded-md">
                {task.dependentOn}
              </span>
            </div>
          )}
        </div>

        {task.recommendation && (
          <div className="mt-2.5 flex items-start gap-1.5 text-xs">
            <Lightbulb className="w-3.5 h-3.5 shrink-0 text-amber-500 mt-0.5" />
            <span className="text-slate-500">
              Recommendation:{" "}
              <span className="italic text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded-md">
                {task.recommendation}
              </span>
            </span>
          </div>
        )}
      </div>

      <div className="border-t border-slate-100 px-4 py-2">
        <button
          onClick={handleCreateIssue}
          className="w-full flex items-center justify-center gap-1.5 text-xs font-medium text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 py-1 rounded-lg transition-colors"
        >
          <Github className="w-3.5 h-3.5" />
          Create GitHub Issue
        </button>
      </div>
    </div>
  );
}

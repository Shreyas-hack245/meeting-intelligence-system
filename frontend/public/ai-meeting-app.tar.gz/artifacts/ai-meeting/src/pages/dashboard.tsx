import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Sparkles, History, LogOut, FileText, 
  Mic, Loader2, PlayCircle, Square, CheckSquare, 
  Download, Copy, Share2, DownloadCloud, Github,
  ChevronDown, User, Plus, Lightbulb, Target, 
  MoreHorizontal, Check, Database, Zap, BookOpen,
  ArrowUpRight, Save
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { KanbanBoard } from "@/components/kanban-board";
import { TaskCard } from "@/components/task-card";
import { Task, TaskStatus, Decision, TranscriptLine } from "@/types";
import { useToast } from "@/hooks/use-toast";

const MOCK_TASKS: Task[] = [
  {
    id: "1",
    title: "Fix Login Bug",
    team: "Backend",
    priority: "HIGH",
    assignee: "Rahul",
    dependentOn: "Database Update",
    status: "TODO"
  },
  {
    id: "2",
    title: "Redesign Dashboard Widget",
    team: "UI/UX",
    priority: "MEDIUM",
    assignee: "Priya",
    status: "BACKLOG"
  },
  {
    id: "3",
    title: "Implement API Rate Limiting",
    team: "API",
    priority: "LOW",
    assignee: "Arjun",
    recommendation: "Use a token bucket algorithm",
    status: "IN_PROGRESS"
  }
];

const MOCK_DECISIONS: Decision[] = [
  { id: "1", text: "Deploy the update next week" },
  { id: "2", text: "Migrate to MongoDB for the new feature" },
  { id: "3", text: "Enable API rate limiting for security" }
];

const MOCK_TRANSCRIPT: TranscriptLine[] = [
  { id: "1", speaker: "Rahul", text: "I will fix the login bug before release.", time: "10:02", isDecision: false },
  { id: "2", speaker: "Priya", text: "The UI team will redesign the dashboard widget.", time: "10:03", isDecision: false },
  { id: "3", speaker: "Arjun", text: "We need to implement rate limiting on the API.", time: "10:05", isDecision: false },
  { id: "4", speaker: "Decision", text: "Deploy the update next week", time: "10:06", isDecision: true }
];

const SPEAKER_COLORS: Record<string, string> = {
  Rahul: "bg-indigo-500",
  Priya: "bg-purple-500",
  Arjun: "bg-emerald-500",
  Decision: "bg-orange-500"
};

const PRIORITY_COLORS: Record<string, string> = {
  HIGH: "bg-red-100 text-red-700 border-red-200",
  MEDIUM: "bg-amber-100 text-amber-700 border-amber-200",
  LOW: "bg-green-100 text-green-700 border-green-200"
};

export default function Dashboard() {
  const { toast } = useToast();
  const [activeMode, setActiveMode] = useState<"transcript" | "live">("live");
  const [isGenerating, setIsGenerating] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [isRecording, setIsRecording] = useState(true);
  const [recordingTime, setRecordingTime] = useState(47);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [transcript, setTranscript] = useState<TranscriptLine[]>(MOCK_TRANSCRIPT);
  const transcriptRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (isRecording) {
      interval = setInterval(() => setRecordingTime(prev => prev + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setTasks(MOCK_TASKS);
      setDecisions(MOCK_DECISIONS);
      setIsGenerating(false);
      setShowResults(true);
      toast({ title: "Analysis Complete ✓", description: "Extracted 3 tasks and 3 key decisions." });
    }, 2000);
  };

  const handleTaskMove = (taskId: string, newStatus: TaskStatus) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: newStatus } : t));
  };

  const handleGitHubIssues = () => {
    toast({ title: "GitHub Issues Created", description: "3 issues have been created in your repository." });
  };

  const handleExportCSV = () => {
    const csv = ["Title,Team,Priority,Assignee,Status",
      ...tasks.map(t => `${t.title},${t.team},${t.priority},${t.assignee},${t.status}`)
    ].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "meeting-tasks.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  const handleSaveHistory = () => {
    toast({ title: "Saved to History", description: "Meeting saved to your history." });
  };

  const handleCopyTasks = () => {
    const text = tasks.map(t => `• ${t.title} [${t.priority}] — ${t.assignee}`).join("\n");
    navigator.clipboard.writeText(text);
    toast({ title: "Copied!", description: "Tasks copied to clipboard." });
  };

  const handleExportJSON = () => {
    const json = JSON.stringify({ tasks, decisions, transcript }, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "meeting-data.json"; a.click();
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans">
      {/* Navbar */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm">
        <div className="max-w-screen-xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-600 to-purple-500 flex items-center justify-center shadow-md shadow-indigo-200">
              <Sparkles className="text-white w-4 h-4" />
            </div>
            <span className="font-bold text-base tracking-tight text-slate-900">AI Meeting Assistant</span>
          </div>

          <div className="flex items-center gap-2">
            <button className="hidden sm:flex items-center gap-1.5 text-sm text-slate-600 hover:text-slate-900 px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-colors">
              <History className="w-4 h-4" />
              Meeting History
              <ChevronDown className="w-3 h-3 opacity-60" />
            </button>
            <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-white shadow-sm">
              <img src={`${import.meta.env.BASE_URL}images/avatar.png`} alt="Avatar" className="w-full h-full object-cover" />
            </div>
            <Link href="/">
              <button className="text-sm text-slate-600 hover:text-slate-900 px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-colors">
                Logout
              </button>
            </Link>
            <button className="flex items-center gap-1.5 text-sm font-medium bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded-lg transition-colors">
              <User className="w-3.5 h-3.5" />
              Account
              <ChevronDown className="w-3 h-3 opacity-80" />
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-screen-xl mx-auto w-full px-4 sm:px-6 py-6 space-y-5">

        {/* Recording Bar */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-2xl shadow-lg"
          style={{ background: "linear-gradient(135deg, #F97316 0%, #7C3AED 50%, #4338CA 100%)" }}
        >
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")" }} />
          <div className="relative px-5 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <motion.div
                animate={{ scale: [1, 1.3, 1], opacity: [1, 0.6, 1] }}
                transition={{ repeat: Infinity, duration: 1.2 }}
                className="w-3 h-3 bg-white rounded-full shadow-md"
              />
              <span className="text-white font-semibold text-sm sm:text-base">
                {isRecording ? "Recording Live Meeting" : "Recording Paused"}
              </span>
              <span className="font-mono text-white/80 text-sm bg-black/20 px-2 py-0.5 rounded-md">
                {formatTime(recordingTime)}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {isRecording ? (
                <button
                  onClick={() => setIsRecording(false)}
                  className="flex items-center gap-1.5 bg-white/20 hover:bg-white/30 text-white text-xs font-medium px-3 py-1.5 rounded-lg transition-colors"
                >
                  <Square className="w-3.5 h-3.5" />
                  Stop
                </button>
              ) : (
                <button
                  onClick={() => setIsRecording(true)}
                  className="flex items-center gap-1.5 bg-white/20 hover:bg-white/30 text-white text-xs font-medium px-3 py-1.5 rounded-lg transition-colors"
                >
                  <PlayCircle className="w-3.5 h-3.5" />
                  Resume
                </button>
              )}
              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="flex items-center gap-1.5 bg-white text-indigo-700 hover:bg-indigo-50 text-xs font-semibold px-4 py-1.5 rounded-lg transition-colors shadow-md disabled:opacity-60"
              >
                {isGenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                {isGenerating ? "Analyzing..." : "Generate Tasks"}
              </button>
            </div>
          </div>
        </motion.div>

        {/* 3-Column Dashboard */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          
          {/* Live Transcript Panel */}
          <div className="bg-gradient-to-b from-slate-800 to-slate-900 rounded-2xl shadow-xl overflow-hidden flex flex-col" style={{ minHeight: 400, maxHeight: 500 }}>
            <div className="px-5 py-4 flex items-center justify-between border-b border-white/10">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-indigo-300" />
                <h3 className="font-semibold text-white text-sm">Live Transcript</h3>
              </div>
              <button className="text-slate-400 hover:text-white transition-colors">
                <MoreHorizontal className="w-4 h-4" />
              </button>
            </div>
            <div ref={transcriptRef} className="flex-1 overflow-y-auto p-4 space-y-3">
              {transcript.map((line) => (
                <motion.div
                  key={line.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-start gap-2.5"
                >
                  {line.isDecision ? (
                    <div className="mt-0.5 shrink-0 w-6 h-6 rounded-full bg-orange-500 flex items-center justify-center">
                      <Zap className="w-3 h-3 text-white" />
                    </div>
                  ) : (
                    <div className={`mt-0.5 shrink-0 w-6 h-6 rounded-full ${SPEAKER_COLORS[line.speaker] || "bg-slate-500"} flex items-center justify-center`}>
                      <span className="text-white text-xs font-bold">{line.speaker[0]}</span>
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    {!line.isDecision && (
                      <span className="text-indigo-300 text-xs font-semibold">{line.speaker}: </span>
                    )}
                    {line.isDecision ? (
                      <div className="mt-1 bg-orange-500/20 border border-orange-500/30 rounded-lg px-3 py-2">
                        <span className="text-orange-300 text-xs font-semibold">Decision: </span>
                        <span className="text-orange-200 text-xs">{line.text}</span>
                      </div>
                    ) : (
                      <p className="text-slate-300 text-xs leading-relaxed">
                        {line.text}
                        {line.speaker === "Rahul" && (
                          <span className="ml-2 inline-block bg-red-500/80 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                            HIGH
                          </span>
                        )}
                      </p>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Action Items Panel */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 flex flex-col overflow-hidden" style={{ minHeight: 400, maxHeight: 500 }}>
            <div className="px-5 py-4 flex items-center justify-between border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-orange-500" />
                <h3 className="font-semibold text-slate-900 text-sm">Action Items</h3>
              </div>
              <button className="text-slate-400 hover:text-slate-700 transition-colors">
                <MoreHorizontal className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {showResults ? (
                tasks.map(task => <TaskCard key={task.id} task={task} />)
              ) : (
                <div className="flex flex-col items-center justify-center h-48 text-center space-y-2">
                  <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center">
                    <Target className="w-6 h-6 text-slate-300" />
                  </div>
                  <p className="text-slate-400 text-sm">Action items will appear here after analysis</p>
                </div>
              )}
            </div>
          </div>

          {/* Key Decisions Panel */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 flex flex-col overflow-hidden" style={{ minHeight: 400, maxHeight: 500 }}>
            <div className="px-5 py-4 flex items-center justify-between border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Lightbulb className="w-4 h-4 text-indigo-500" />
                <h3 className="font-semibold text-slate-900 text-sm">Key Decisions</h3>
              </div>
              <button className="text-slate-400 hover:text-slate-700 transition-colors">
                <MoreHorizontal className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {showResults ? (
                decisions.map(d => (
                  <motion.div
                    key={d.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-start gap-3 p-3 bg-indigo-50 rounded-xl border border-indigo-100 hover:shadow-sm transition-all"
                  >
                    <div className="shrink-0 w-5 h-5 rounded-md bg-indigo-600 flex items-center justify-center mt-0.5">
                      <Check className="w-3 h-3 text-white" strokeWidth={3} />
                    </div>
                    <p className="text-slate-800 text-sm font-medium leading-snug">{d.text}</p>
                  </motion.div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center h-48 text-center space-y-2">
                  <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center">
                    <Lightbulb className="w-6 h-6 text-slate-300" />
                  </div>
                  <p className="text-slate-400 text-sm">Key decisions will appear here after analysis</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Meeting Summary Bar */}
        <div
          className="rounded-2xl px-5 py-3.5 flex flex-col sm:flex-row items-start sm:items-center gap-2 shadow-lg"
          style={{ background: "linear-gradient(135deg, #4338CA 0%, #6D28D9 60%, #7C3AED 100%)" }}
        >
          <span className="text-white font-bold text-sm shrink-0">Meeting Summary</span>
          <span className="text-indigo-200 text-xs sm:text-sm italic">
            · Summary: {showResults
              ? "Discussed fixing the login bug, redesigning the dashboard, and implementing API rate limiting."
              : "Start recording and generate tasks to see the meeting summary here."}
          </span>
        </div>

        {/* Action Buttons Row */}
        <div className="flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={handleGitHubIssues}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold px-5 py-2.5 rounded-xl shadow-md shadow-indigo-200 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Create GitHub Issues
          </button>
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold px-5 py-2.5 rounded-xl shadow-md shadow-indigo-200 transition-colors"
          >
            <Download className="w-4 h-4" />
            Export to CSV
          </button>
          <button
            onClick={handleSaveHistory}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold px-5 py-2.5 rounded-xl shadow-md shadow-indigo-200 transition-colors"
          >
            <Save className="w-4 h-4" />
            Save to History
          </button>
          <button
            onClick={handleCopyTasks}
            className="flex items-center gap-2 bg-white hover:bg-slate-50 text-slate-700 text-sm font-medium px-4 py-2.5 rounded-xl border border-slate-200 shadow-sm transition-colors"
          >
            <Copy className="w-4 h-4" />
            Copy Tasks
          </button>
          <button
            onClick={handleExportJSON}
            className="flex items-center gap-2 bg-white hover:bg-slate-50 text-slate-700 text-sm font-medium px-4 py-2.5 rounded-xl border border-slate-200 shadow-sm transition-colors"
          >
            <ArrowUpRight className="w-4 h-4" />
            Export JSON
          </button>
        </div>

        {/* Kanban Board */}
        {showResults && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-slate-900">Trello Storyboard</h2>
                <p className="text-slate-500 text-sm">Drag and drop to update task status</p>
              </div>
              <button
                onClick={() => setShowResults(false)}
                className="text-sm text-slate-500 hover:text-slate-700 px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-colors"
              >
                + New Meeting
              </button>
            </div>
            <KanbanBoard tasks={tasks} onTaskMove={handleTaskMove} />
          </motion.div>
        )}

        {/* Transcript Mode Fallback UI */}
        {!showResults && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex p-1 bg-slate-100 rounded-xl w-fit">
                <button
                  onClick={() => setActiveMode("transcript")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                    activeMode === "transcript"
                      ? "bg-white shadow text-indigo-600"
                      : "text-slate-500 hover:text-slate-800"
                  }`}
                >
                  <FileText className="w-4 h-4" />
                  Transcript Mode
                </button>
                <button
                  onClick={() => setActiveMode("live")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                    activeMode === "live"
                      ? "bg-white shadow text-indigo-600"
                      : "text-slate-500 hover:text-slate-800"
                  }`}
                >
                  <Mic className="w-4 h-4" />
                  Live Meeting Mode
                </button>
              </div>
            </div>

            {activeMode === "transcript" ? (
              <div className="space-y-4">
                <textarea
                  className="w-full h-48 bg-slate-50 border border-slate-200 rounded-xl p-4 text-sm focus:outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-200 transition-all resize-none"
                  placeholder="Paste your meeting transcript here... (e.g. 'Rahul: I will fix the login bug before release. Priya: The UI team will redesign the dashboard widget...')"
                />
                <div className="flex justify-between items-center">
                  <button className="flex items-center gap-2 text-sm text-slate-600 border border-slate-200 hover:border-slate-300 px-4 py-2 rounded-xl transition-colors">
                    <DownloadCloud className="w-4 h-4" />
                    Upload .txt File
                  </button>
                  <button
                    onClick={handleGenerate}
                    disabled={isGenerating}
                    className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold px-6 py-2.5 rounded-xl shadow-md shadow-indigo-200 transition-all disabled:opacity-60"
                  >
                    {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    {isGenerating ? "Analyzing..." : "Generate Insights"}
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-10 space-y-4">
                <div className="relative">
                  <div className="w-20 h-20 rounded-full bg-indigo-100 flex items-center justify-center">
                    <Mic className="w-9 h-9 text-indigo-600" />
                  </div>
                  {isRecording && (
                    <motion.div
                      animate={{ scale: [1, 1.5, 1], opacity: [0.6, 0, 0.6] }}
                      transition={{ repeat: Infinity, duration: 2 }}
                      className="absolute inset-0 rounded-full border-4 border-indigo-400"
                    />
                  )}
                </div>
                <p className="text-slate-600 text-sm font-medium">
                  {isRecording ? "Listening to your meeting..." : "Ready to record"}
                </p>
                <button
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold px-6 py-2.5 rounded-xl shadow-md shadow-indigo-200 transition-all disabled:opacity-60"
                >
                  {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  {isGenerating ? "Generating..." : "Generate Tasks"}
                </button>
              </div>
            )}
          </div>
        )}

      </main>
    </div>
  );
}
